<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<html>
<head>
<title>CSRF mit GET</title>
</head>
<body>
<h2>CSRF mit GET</h2>
<a href="../XSS/basic.php?search=pr0n">Klick mich!</a><br>
<br>
<hr>
<br>
<h2>HTML Code</h2>
<pre>
<? echo htmlentities('<a href="../XSS/basic.php?search=pr0n">Klick mich!</a>', ENT_QUOTES); ?>
</pre>
<br>
<hr>
<a href="./../index.html">index</a>
</body>
</html>