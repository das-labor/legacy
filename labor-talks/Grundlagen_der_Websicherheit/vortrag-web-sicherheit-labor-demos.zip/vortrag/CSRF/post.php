<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<html>
<head>
<title>CSRF mit POST</title>
</head>
<body>
<h2>CSRF mit POST</h2>
<a href="../CSRF/trigger.php">Klick mich!</a><br>
<br>
<hr>
<h2>HTML Code</h2>
<pre>
<? echo htmlentities('<a href="../CSRF/trigger.php">Klick mich!</a>', ENT_QUOTES); ?>
</pre>
<hr>
<h2>trigger.php HTML Code</h2>
<pre>
<? echo htmlentities('<body onload=\'document.forms[0].submit()\'>

<form method="POST" action="./../XSS/advanced.php">
<input type="hidden" value="pr0n" name="search">
</form>', ENT_QUOTES); ?>
</pre>
<br>
<hr>
<a href="./../index.html">index</a>
</body>
</html>