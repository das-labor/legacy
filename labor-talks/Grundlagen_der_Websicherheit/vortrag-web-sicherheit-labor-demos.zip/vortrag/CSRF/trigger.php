<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<html>
<head>
</head>
<body onload='document.forms[0].submit()'>

<form method="POST" action="./../XSS/advanced.php">
<input type="hidden" value="pr0n" name="search">
</form>

</body>
</html>