<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<? setcookie("Cookie", "geheim"); ?>


<html>
<head>
<title>Advanced XSS</title>
</head>
<body>
<h2>XSS: Suchmaschine 2</h2>
<form method="POST" action="advanced.php">
<input type="text" size=40 name="search" value="
<? if(!empty($_POST['search']))
   {
	$input = $_POST['search'];
	$input = str_replace("<", "&lt;", $input);
	$input = str_replace(">", "&gt;", $input);
	echo $input;
   }
   else
	echo "Suchbegriff eingeben!"; 
?>"><input type="submit" value="suchen">
</form>
<br>
<hr>
<br>
<h2>HTML Code</h2>
<pre>
&lt;form method="POST" action="advanced.php"&gt;
	&lt;input type="text" name="search" value="<? if(!empty($_POST['search']))
   {
	$input = $_POST['search'];
	$input = str_replace("<", "&lt;", $input);
	$input = str_replace(">", "&gt;", $input);
	echo "<font color=red><b>".htmlentities($input, ENT_QUOTES)."</b></font>";
   }
   else
	echo "Suchbegriff eingeben!"; 
?>"&gt;
	&lt;input type="submit" value="suchen"&gt;
&lt;/form&gt;
</pre>
<br>
<hr>
<a href="./../index.html">index</a>
</body>
</html>