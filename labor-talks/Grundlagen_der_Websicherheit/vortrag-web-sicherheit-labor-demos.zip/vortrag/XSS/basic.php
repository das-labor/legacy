<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<? $value="geheim"; setcookie("Cookie", $value); ?>
<html>
<head>
<title>Basic XSS</title>
</head>
<body>
<h2>XSS: Suchmaschine 1</h2>
<form method="GET" action="basic.php">
<input type="text" size=40 name="search" value="
<? if(!empty($_GET['search']))
	echo $_GET['search'];
   else
	echo "Suchbegriff eingeben!"; 
?>"><input type="submit" value="suchen">
</form>
<br>
<hr>
<br>
<h2>HTML Code</h2>
<pre>
&lt;form method="GET" action="basic.php"&gt;
	&lt;input type="text" name="search" value="<? if(!empty($_GET['search']))
	echo "<font color=red><b>".htmlentities($_GET['search'], ENT_QUOTES)."</b></font>";
   else
	echo "Suchbegriff eingeben!"; 
?>"&gt;
	&lt;input type="submit" value="suchen"&gt;
&lt;/form&gt;
</pre>
<br>
<hr>
<a href="./../index.html">index</a>
</body>
</html>