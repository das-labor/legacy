<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<html>
<head>
<title>Basic SQL injection</title>
</head>
<body>
<h2>SQL Injection</h2>
<?php
    $Host     = "localhost";
    $User     = "Reiners";
    $Password = "";
    $Database = "test";


$conn = @mysql_connect($Host, $User, $Password) 
	or die("Error: Can not open data base. net start MySQL");

@mysql_select_db($Database, $conn) or die(mysql_error());

if(!empty($_GET["id"]))
	$query = "SELECT id,name FROM users WHERE id = ".$_GET["id"]."";

if(!empty($_GET["query"]))
	$query = $_GET["query"];

echo "\$query = SELECT id,name FROM users WHERE id = <font color=red><b>".$_GET["id"]."</b></font>;<br><br><hr>";
$result = mysql_query($query) or die('Query failed: ' . mysql_error());


// Printing results in HTML
echo "<table width=500><tr><td valign=top><table border=1><tr><td colspan=2><i>result:</i></td></tr>\n";
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table></td><td align=right valign=top>
<table border=1><tr><td colspan=3><i>table users</i></td></tr>
<tr><th>id</th><th>name</th><th>password</th></tr>
<tr><td>1</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>2</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>3</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>...</td><td>&nbsp;</td><td>&nbsp;</td></tr>
</td></tr></table>
</td></tr></table>\n";

// Free resultset
mysql_free_result($result);


mysql_close($conn);


?>
<hr>
<a href="./../index.html">index</a>
</body>
</html>
