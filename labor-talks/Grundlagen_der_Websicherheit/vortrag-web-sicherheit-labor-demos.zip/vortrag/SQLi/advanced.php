<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<html>
<head>
<title>Basic SQL injection</title>
</head>
<body>
<h2>SQL Injection</h2>

<form action="advanced.php" method="GET">
<table>
<tr><th colspan=2>Login!</th></tr>
<tr><td>Name:</td><td><input type="text" name="name"></td></tr>
<tr><td>Password:</td><td><input type="text" name="password"></td></tr>
<tr><td colspan=2 align=right><input type="submit" name="login"></td></tr>
</table>
<hr>
<?php
    $Host     = "localhost";
    $User     = "Reiners";
    $Password = "";
    $Database = "test";


$conn = @mysql_connect($Host, $User, $Password) 
	or die("Error: Can not open data base. net start MySQL");

@mysql_select_db($Database, $conn) or die(mysql_error());

if(!empty($_GET["name"]) && !empty($_GET["name"]))
	$query = "SELECT id,name,password FROM users WHERE name = '".$_GET["name"]."' AND password = '".$_GET["password"]."';";
else
	die("<font color=red><b>Please enter username and password!</b></font>");

if(!empty($_GET["query"]))
	$query = $_GET["query"];

echo "\$query = SELECT id,name,password FROM users WHERE name = '<font color=red><b>".$_GET["name"]."</b></font>' AND password = '<font color=red><b>".$_GET["password"]."</b></font>';<br><br>";
$result = mysql_query($query) or die('<font color=red><b>Login failed!</b></font><br>'.mysql_error());

echo "<table width=500><tr><td valign=top><table border=1>\n";

$line = mysql_fetch_array($result, MYSQL_ASSOC);
if(!empty($line))
{
// Printing results in HTML
echo "<font color=green><b>Login successful!</b></font><br>
Your Account Details:<br>";
echo "\t<tr>\n";
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
  while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
  }


} else
{
	echo "<font color=red><b>Login failed!</b></font>";
}
echo "</table></td><td align=right valign=top>
<table border=1><tr><td colspan=3><i>table users</i></td></tr>
<tr><th>id</th><th>name</th><th>password</th></tr>
<tr><td>1</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>2</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>3</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>...</td><td>&nbsp;</td><td>&nbsp;</td></tr>
</td></tr></table>\n";

// Free resultset
mysql_free_result($result);


mysql_close($conn);


?>
<hr>
<a href="./../index.html">index</a>
</body>
</html>
