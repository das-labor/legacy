<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<html>
<head>
<title>Remote File Inclusion</title>
</head>
<body>
<h2>Remote File Inclusion / Null-Byte Injection</h2>
<h3>include2.php?file=<? $coded = urlencode($_GET['file']); $coded = str_replace("%2F", "/", $coded); $coded = str_replace("%3A", ":", $coded); echo $coded; ?></h3>
<iframe src="./include2.php?file=<? echo urlencode($_GET['file']); ?>" height=100 width=500></iframe><br>
<br>
<hr>
<h2>include2.php PHP Code</h2>
<pre>
<? echo '&lt;?php include($_GET[\'file\'].".html"); ?&gt;'; ?>


<? echo '&lt;?php include("<font color=red><b>'; echo $coded; echo '</b></font>.html"); ?&gt;';
?>
</pre>
<br>
<hr>
<a href="./../index.html">index</a>
</body>
</html>