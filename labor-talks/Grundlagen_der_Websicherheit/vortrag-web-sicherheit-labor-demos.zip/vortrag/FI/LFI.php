<!--
Grundlagen der Web-Sicherheit Demo File
Johannes Dahse, Felix Gr�bert
Warnung: Die Skripte sind totaler schrott und verwundbar
-->

<html>
<head>
<title>Local File Inclusion</title>
</head>
<body>
<h2>Local File Inclusion / Path Traversal</h2>
<h3>include1.php?file=<? $coded = urlencode($_GET['file']); echo str_replace("%2F", "/", $coded); ?></h3>
<iframe src="./include1.php?file=<? echo urlencode($_GET['file']); ?>" height=100 width=500></iframe><br>
<br>
<hr>
<h2>include.php PHP Code</h2>
<pre>
<? echo '&lt;?php include("inc/".$_GET[\'file\']); ?&gt;'; ?>


<? echo '&lt;?php include("inc/<font color=red><b>'; echo str_replace("%2F", "/", $coded); echo '</b></font>"); ?&gt;';
?>
</pre>
<br>
<hr>
<a href="./../index.html">index</a>
</body>
</html>